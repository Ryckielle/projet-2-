<?php

define("ROOT_PATH", realpath(dirname(__FILE__)));

// Détecte dynamiquement l'URL de base (pratique en développement local)
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || 
			(isset($_SERVER['SERVER_PORT']) && $_SERVER['SERVER_PORT'] == 443) ? 'https://' : 'http://';
$host = $_SERVER['HTTP_HOST'] ?? 'localhost';

// Calculate web path to project root based on DOCUMENT_ROOT and filesystem ROOT_PATH
$docRoot = realpath($_SERVER['DOCUMENT_ROOT']);
$projectRoot = str_replace('\\', '/', ROOT_PATH);
$docRoot = str_replace('\\', '/', $docRoot);
$basePath = str_replace($docRoot, '', $projectRoot);
if ($basePath === '') {
	$basePath = '/';
}
define('BASE_URL', rtrim($protocol . $host . $basePath, '/'));
