<?php
// Simple contact form handler: saves messages to app/database/messages.txt
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('HTTP/1.1 405 Method Not Allowed');
    exit;
}

$email = filter_var($_POST['email'] ?? '', FILTER_SANITIZE_EMAIL);
$message = trim($_POST['message'] ?? '');

$referer = $_SERVER['HTTP_REFERER'] ?? 'index.php';

if (!filter_var($email, FILTER_VALIDATE_EMAIL) || $message === '') {
    header('Location: ' . $referer . (strpos($referer, '?') === false ? '?' : '&') . 'contact=error');
    exit;
}

$data = [
    'email' => $email,
    'message' => $message,
    'ip' => $_SERVER['REMOTE_ADDR'] ?? '',
    'time' => date('c')
];

$dir = __DIR__ . '/app/database';
if (!is_dir($dir)) { mkdir($dir, 0755, true); }
$file = $dir . '/messages.txt';
file_put_contents($file, json_encode($data, JSON_UNESCAPED_UNICODE) . PHP_EOL, FILE_APPEND | LOCK_EX);

header('Location: ' . $referer . (strpos($referer, '?') === false ? '?' : '&') . 'contact=ok');
exit;
