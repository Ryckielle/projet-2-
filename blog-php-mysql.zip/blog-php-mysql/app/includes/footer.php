 <!-- footer -->
 <div class="footer">
    <div class="footer-content">

      <div class="footer-section about">
        <h1 class="logo-text"><span>Ryckielle</span>-Buzz</h1>
        <p>
          Ryckielle-Buzz est un blog dedié au partage des évenements et tendances qui font le buzz sur le web . Passionné pas la développement web , je partage ici mon regard sur l'actualité digitale et les innovations qui façonnent l'internet de demain.
        </p>
        <div class="contact">
          <span><i class="fas fa-phone"></i> &nbsp; 0141114831</span>
          <span><i class="fas fa-envelope"></i> &nbsp; floreryckielleodou@gmail.com</span>
        </div>
        <div class="socials">
          <a href="#"><i class="fab fa-facebook"></i></a>
          <a href="#"><i class="fab fa-instagram"></i></a>
          <a href="#"><i class="fab fa-twitter"></i></a>
          <a href="#"><i class="fab fa-youtube"></i></a>
        </div>
      </div>

      <div class="footer-section links">
        <h2>Liens rapides</h2>
        <br>
        <ul>
          <a href="#">
            <li>Évènements</li>
          </a>
          <a href="#">
            <li>Équipe</li>
          </a>
          <a href="#">
            <li>Mentors</li>
          </a>
          <a href="#">
            <li>Galerie</li>
          </a>
          <a href="#">
            <li>Conditions d'utilisation</li>
          </a>
        </ul>
      </div>

      <div class="footer-section contact-form">
        <h2>Nous contacter</h2>
        <br>
        <?php if (!defined('BASE_URL')) { include_once __DIR__ . '/../../path.php'; } ?>
        <form action="<?php echo BASE_URL . '/contact.php'; ?>" method="post">
          <input type="email" name="email" class="text-input contact-input" placeholder="Votre adresse e-mail...">
          <textarea rows="4" name="message" class="text-input contact-input" placeholder="Votre message..."></textarea>
          <button type="submit" class="btn btn-big contact-btn">
            <i class="fas fa-envelope"></i>
            Envoyer
          </button>
        </form>
      </div>

    </div>

    <div class="footer-bottom">
      &copy; 2026 Ryckielle-Buzz | conçu par Ryckielle
    </div>
  </div>
  <!-- // footer -->