<div class="left-sidebar">
    <ul>
        <li><a href="<?php echo BASE_URL . '/admin/posts/index.php'; ?>">Gérer les articles</a></li>
        <li><a href="<?php echo BASE_URL . '/admin/users/index.php'; ?>">Gérer les utilisateurs</a></li>
        <li><a href="<?php echo BASE_URL . '/admin/buzz/index.php'; ?>">Gérer les buzz</a></li>
    </ul>
</div>