<?php

include(ROOT_PATH . "/app/database/db.php");
include(ROOT_PATH . "/app/helpers/middleware.php");
include(ROOT_PATH . "/app/helpers/validateBuzz.php");

$table = 'buzzes';

$errors = array();
$id = '';
$name = '';
$description = '';

$buzzes = selectAll($table);


if (isset($_POST['add-buzz'])) {
    adminOnly();
    $errors = validateBuzz($_POST);

    if (count($errors) === 0) {
        unset($_POST['add-buzz']);
        $buzz_id = create($table, $_POST);
        $_SESSION['message'] = 'Catégorie créée avec succès';
        $_SESSION['type'] = 'success';
        header('location: ' . BASE_URL . '/admin/buzz/index.php');
        exit(); 
    } else {
        $name = $_POST['name'];
        $description = $_POST['description'];
    }
}


if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $buzz = selectOne($table, ['id' => $id]);
    $id = $buzz['id'];
    $name = $buzz['name'];
    $description = $buzz['description'];
}

if (isset($_GET['del_id'])) {
    adminOnly();
    $id = $_GET['del_id'];
    $count = delete($table, $id);
    $_SESSION['message'] = 'Catégorie supprimée avec succès';
    $_SESSION['type'] = 'success';
    header('location: ' . BASE_URL . '/admin/buzz/index.php');
    exit();
}


if (isset($_POST['update-buzz'])) {
    adminOnly();
    $errors = validateBuzz($_POST);

    if (count($errors) === 0) { 
        $id = $_POST['id'];
        unset($_POST['update-buzz'], $_POST['id']);
        $buzz_id = update($table, $id, $_POST);
        $_SESSION['message'] = 'Catégorie mise à jour avec succès';
        $_SESSION['type'] = 'success';
        header('location: ' . BASE_URL . '/admin/buzz/index.php');
        exit();
    } else {
        $id = $_POST['id'];
        $name = $_POST['name'];
        $description = $_POST['description'];
    }

}
