<?php


function validatePost($post)
{
    $errors = array();

    if (empty($post['title'])) {
        array_push($errors, 'Le titre est requis');
    }

    if (empty($post['body'])) {
        array_push($errors, 'Le contenu est requis');
    }

    if (empty($post['buzz_id'])) {
        array_push($errors, 'Veuillez sélectionner une catégorie');
    }

    $existingPost = selectOne('posts', ['title' => $post['title']]);
    if ($existingPost) {
        if (isset($post['update-post']) && $existingPost['id'] != $post['id']) {
            array_push($errors, 'Un article avec ce titre existe déjà');
        }

        if (isset($post['add-post'])) {
            array_push($errors, 'Un article avec ce titre existe déjà');
        }
    }

    return $errors;
}