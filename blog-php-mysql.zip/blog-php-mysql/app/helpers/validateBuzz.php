<?php

function validateBuzz($buzz)
{
    $errors = array();

    if (empty($buzz['name'])) {
        array_push($errors, 'Le nom est requis');
    }

    $existingBuzz = selectOne('buzzes', ['name' => $buzz['name']]);
    if ($existingBuzz) {
        if (isset($buzz['update-buzz']) && $existingBuzz['id'] != $buzz['id']) {
            array_push($errors, 'Ce nom existe déjà');
        }

        if (isset($buzz['add-buzz'])) {
            array_push($errors, 'Ce nom existe déjà');
        }
    }

    return $errors;
}
