<?php
// Script pour créer un utilisateur admin. Exécuter une fois via le navigateur : /blog/create_admin.php
include('path.php');
include(ROOT_PATH . '/app/database/db.php');

$username = 'admin';
$email = 'admin@example.com';
$password = 'Admin@123';

// Vérifier l'utilisateur existant
$existing = selectOne('users', ['username' => $username]);
if ($existing) {
    echo "L'utilisateur '$username' existe déjà.\n";
    echo "Si vous voulez réinitialiser le mot de passe, modifiez le script ou mettez à jour la base de données manuellement.\n";
    exit;
}

$hashed = password_hash($password, PASSWORD_DEFAULT);
$user_id = create('users', ['username' => $username, 'email' => $email, 'password' => $hashed, 'admin' => 1]);

if ($user_id) {
    echo "Utilisateur admin créé avec succès.\n";
    echo "Nom d'utilisateur: $username\n";
    echo "Mot de passe: $password\n";
    echo "Veuillez supprimer ce fichier (create_admin.php) après vérification que vous pouvez vous connecter.\n";
} else {
    echo "Impossible de créer un utilisateur admin. Vérifiez la connexion à la base de données et les autorisations.\n";
}
