<?php include("../../path.php"); ?>
<?php include(ROOT_PATH . "/app/controllers/posts.php");
adminOnly();
?>
<!DOCTYPE html>
<html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">

        <!-- Font Awesome -->
        <link rel="stylesheet"
            href="https://use.fontawesome.com/releases/v5.7.2/css/all.css"
            integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr"
            crossorigin="anonymous">

        <!-- Google Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Candal|Lora"
            rel="stylesheet">

        <!-- Custom Styling -->
        <link rel="stylesheet" href="<?php echo BASE_URL . '/assets/css/style.css'; ?>">

        <!-- Admin Styling -->
        <link rel="stylesheet" href="<?php echo BASE_URL . '/assets/css/admin.css'; ?>">

        <title>Section Admin - Gérer les articles</title>
    </head>

    <body>
        
    <?php include(ROOT_PATH . "/app/includes/adminHeader.php"); ?>

        <!-- Admin Page Wrapper -->
        <div class="admin-wrapper">

        <?php include(ROOT_PATH . "/app/includes/adminSidebar.php"); ?>


            <!-- Admin Content -->
            <div class="admin-content">
                    <div class="button-group">
                    <a href="<?php echo BASE_URL . '/admin/posts/create.php'; ?>" class="btn btn-big">Ajouter un article</a>
                    <a href="<?php echo BASE_URL . '/admin/posts/index.php'; ?>" class="btn btn-big">Gérer les articles</a>
                </div>


                <div class="content">

                    <h2 class="page-title">Gérer les articles</h2>

                    <?php include(ROOT_PATH . "/app/includes/messages.php"); ?>

                    <table>
                        <thead>
                            <th>N</th>
                            <th>Titre</th>
                            <th>Auteur</th>
                            <th colspan="3">Action</th>
                        </thead>
                        <tbody>
                            <?php foreach ($posts as $key => $post): ?>
                                <tr>
                                    <td><?php echo $key + 1; ?></td>
                                    <td><?php echo $post['title'] ?></td>
                                    <td>Ryckielle</td>
                                    <td><a href="<?php echo BASE_URL . '/admin/posts/edit.php?id=' . $post['id']; ?>" class="edit">modifier</a></td>
                                    <td><a href="<?php echo BASE_URL . '/admin/posts/edit.php?delete_id=' . $post['id']; ?>" class="delete">supprimer</a></td>

                                    <?php if ($post['published']): ?>
                                        <td><a href="<?php echo BASE_URL . '/admin/posts/edit.php?published=0&p_id=' . $post['id']; ?>" class="unpublish">dépublier</a></td>
                                    <?php else: ?>
                                        <td><a href="<?php echo BASE_URL . '/admin/posts/edit.php?published=1&p_id=' . $post['id']; ?>" class="publish">publier</a></td>
                                    <?php endif; ?>
                                    
                                </tr>
                            <?php endforeach; ?>

                        </tbody>
                    </table>

                </div>

            </div>
            <!-- // Admin Content -->

        </div>
        <!-- // Page Wrapper -->



        <!-- JQuery -->
        <script
            src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <!-- Ckeditor -->
        <script
            src="https://cdn.ckeditor.com/ckeditor5/12.2.0/classic/ckeditor.js"></script>
        <!-- Custom Script -->
        <script src="<?php echo BASE_URL . '/assets/js/scripts.js'; ?>"></script>

    </body>

</html>